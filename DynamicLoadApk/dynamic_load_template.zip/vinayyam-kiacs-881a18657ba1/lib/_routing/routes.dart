const String landingViewRoute = '/';

const String loginViewRoute = 'login';
const String dashboardViewRoute = 'dashboard';
const String speakersViewRoute = 'speakers';
const String venueViewRoute = 'venue';
const String aboutViewRoute = 'about';
const String sponsorsViewRoute = 'sponsors';
const String agendaViewRoute = 'agenda';
const String galleryViewRoute = 'gallery';
const String youtubeViewRoute = 'youtube';
const String registerViewRoute = 'register';
const String surveyViewRoute = 'survey';
const String resetPasswordViewRoute = 'reset_password';

const String homeViewRoute = 'home';
const String chatDetailsViewRoute = 'chat_details';
const String userDetailsViewRoute = 'user_details';