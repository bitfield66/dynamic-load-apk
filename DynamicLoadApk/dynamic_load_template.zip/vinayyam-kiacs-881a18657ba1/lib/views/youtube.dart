import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class YoutubePage extends StatefulWidget {
  @override
  _YoutubePage createState() => new _YoutubePage();
}

class _YoutubePage extends State<YoutubePage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text('KIACS - Youtube'),
      ),
      body: WebviewScaffold(
        url: 'https://www.youtube.com/channel/UCS7WuD-CM9O-fu2YSB2_dtw',
        withZoom: true,
        withLocalStorage: true,
        hidden: true,
        initialChild: Container(
          color: Colors.grey,
          child: const Center(
            child: SizedBox(
              width: 40.0,
              height: 40.0,
              child: CircularProgressIndicator(),
            ),
          ),
        ),
      ),
    );
  }
}
