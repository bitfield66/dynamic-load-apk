import 'package:flutter/material.dart';
import 'package:kiacs/_routing/routes.dart';
import 'package:kiacs/_routing/router.dart' as router;
import 'package:kiacs/theme.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:kiacs/views/survey.dart';

class MyApp extends StatefulWidget {
  @override
  _MyApp createState() => new _MyApp();
}

class _MyApp extends State<MyApp> {
  FirebaseMessaging firebaseMessaging = new FirebaseMessaging();

  @override
  void initState() {
    super.initState();
    print("onLaunch: initState");
    firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        navigateToSurvey(message['data']['url']);
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        navigateToSurvey(message['data']['url']);
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
        navigateToSurvey(message['data']['url']);
      },
    );
    firebaseMessaging.requestNotificationPermissions(
        IosNotificationSettings(sound: true, badge: true, alert: true));
  }

  void navigateToSurvey(String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SurveyPage(url),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KIACS',
      debugShowCheckedModeBanner: false,
      theme: buildThemeData(),
      onGenerateRoute: router.generateRoute,
      initialRoute: landingViewRoute,
    );
  }
}
