import 'package:kiacs/models/agenda_do.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AgendaController {
  List<AgendaDO> listModelOne;
  List<AgendaDO> listModelTwo;

  AgendaController() {
    listModelOne = List<AgendaDO>();
    listModelTwo = List<AgendaDO>();
  }

  List<AgendaDO> getListModelOne() {
    if (listModelOne != null) {
      listModelOne.add(AgendaDO(
        "Registration (Counter Open)",
        "2 hrs.",
        "7:00",
        "9:00",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Reception and Breakfast",
        "90 mins.",
        "7:30",
        "9:00",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Ribbon Cutting & National Anthem",
        "05 mins.",
        "9:00",
        "9:05",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Quran Recital",
        "05 mins.",
        "9:05",
        "9:10",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Conference Welcome & Safety Moment",
        "05 mins.",
        "9:10",
        "9:15",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Inaugural Address",
        "10 mins.",
        "9:15",
        "9:25",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Welcome Speech",
        "10 mins.",
        "9:25",
        "9:35",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Why are we here? (Video)",
        "10 mins.",
        "9:35",
        "9:45",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Executives Panel Discussion Session",
        "30 mins.",
        "9:45",
        "10:15",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Gratitude",
        "05 mins.",
        "10:15",
        "10:20",
        "",
      ));
      listModelOne.add(AgendaDO(
        "BEN MILLER  - Keynote Speech",
        "30 mins.",
        "10:20",
        "10:50",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Exhibition Opening Ceremony &  NETWORKING",
        "15 mins.",
        "10:50",
        "11:05",
        "",
      ));
      listModelOne.add(AgendaDO(
        "LAYALI AL-MANSOURI - TS#1",
        "25 mins.",
        "11:05",
        "11:30",
        "",
      ));
      listModelOne.add(AgendaDO(
        "PRAYER and LUNCH BREAK",
        "1 hr.",
        "11:30",
        "12:30",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Lucky Draw",
        "05 mins.",
        "12:30",
        "12:35",
        "",
      ));
      listModelOne.add(AgendaDO(
        "FireEye Cyber Attack Simulation - Interactive Session",
        "50 mins.",
        "12:35",
        "13:25",
        "",
      ));
      listModelOne.add(AgendaDO(
        "JOEL LANGIL - TS#2",
        "25 mins.",
        "13:25",
        "13:50",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Networking Session",
        "15 mins.",
        "13:50",
        "14:05",
        "",
      ));
      listModelOne.add(AgendaDO(
        "OMAR SHERIN - TS#3",
        "25 mins.",
        "14:05",
        "14:30",
        "",
      ));
      listModelOne.add(AgendaDO(
        "IRA WINKLER - TS#4",
        "25 mins.",
        "14:30",
        "14:55",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Lucky Draw",
        "05 mins.",
        "14:55",
        "15:00",
        "",
      ));
      listModelOne.add(AgendaDO(
        "Day 1 Closeout",
        "-",
        "15:00",
        "15:00",
        "",
      ));
    }

//    for (int i = 0; i < listModelOne.length; i++) {
//      Map<String, String> values = new Map();
//      values.putIfAbsent("name", () => listModelOne[i].getName());
//      values.putIfAbsent("from", () => listModelOne[i].getFrom());
//      values.putIfAbsent("to", () => listModelOne[i].getTo());
//      values.putIfAbsent("duration", () => listModelOne[i].getDuration());
//      values.putIfAbsent("session", () => listModelOne[i].getSession());
//      Firestore.instance
//          .collection("agenda-one")
//          .document(listModelOne[i].getName())
//          .setData(values);
//    }
    return listModelOne;
  }

  List<AgendaDO> getListModelTwo() {
    if (listModelTwo != null) {
      listModelTwo.add(AgendaDO(
        "Registration & Breakfast",
        "1 hr. & half",
        "7:00",
        "8:30",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Safety Moment",
        "5 mins.",
        "8:30",
        "8:35",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "ERIC BYRES - Keynote Speech",
        "30 mins.",
        "8:35",
        "9:05",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "SAM WILSON - TS#5",
        "25 mins.",
        "9:05",
        "9:30",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "PETER REYNOLDS - TS#6",
        "25 mins.",
        "9:30",
        "9:55",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "JAY ABDALLAH - TS#7",
        "25 mins.",
        "9:55",
        "10:20",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "NETWORKING",
        "10 mins.",
        "10:20",
        "10:30",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Dr. TASSOS DIMITRIOU - TS#8",
        "15 mins.",
        "10:30",
        "10:45",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Technical Panel Discussion Session",
        "30 mins.",
        "10:45",
        "11:15",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "PRAYER & LUNCH BREAK",
        "1 hr.",
        "11:15",
        "12:15",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Lucky Draw",
        "5 mins.",
        "12:15",
        "12:20",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "JOHN MATHERLY - TS#9",
        "25 mins.",
        "12:20",
        "12:45",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Conference Highlights",
        "10 mins.",
        "12:45",
        "12:55",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Lucky Draw",
        "5 mins.",
        "12:55",
        "13:00",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Kaspersky Industrial Protection Simulation (KIPS) - Interactive Session",
        "2 hrs.",
        "13:00",
        "15:00",
        "",
      ));
      listModelTwo.add(AgendaDO(
        "Closeout",
        "-",
        "15:00",
        "15:00",
        "",
      ));
    }

//    for (int i = 0; i < listModelTwo.length; i++) {
//      Map<String, String> values = new Map();
//      values.putIfAbsent("name", () => listModelTwo[i].getName());
//      values.putIfAbsent("from", () => listModelTwo[i].getFrom());
//      values.putIfAbsent("to", () => listModelTwo[i].getTo());
//      values.putIfAbsent("duration", () => listModelTwo[i].getDuration());
//      values.putIfAbsent("session", () => listModelTwo[i].getSession());
//      Firestore.instance
//          .collection("agenda-two")
//          .document(listModelTwo[i].getName())
//          .setData(values);
//    }
    return listModelTwo;
  }
}
