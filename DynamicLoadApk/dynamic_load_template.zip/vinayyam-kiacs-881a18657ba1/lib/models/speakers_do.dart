class SpeakersDO {
  String title;
  String image;
  String content;
  String description;

  SpeakersDO setTitle(String title) {
    this.title = title;
    return this;
  }

  SpeakersDO setDescription(String description) {
    this.description = description;
    return this;
  }

  SpeakersDO setImage(String image) {
    this.image = image;
    return this;
  }

  SpeakersDO setContent(String content) {
    this.content = content;
    return this;
  }

  String getImage() {
    return image;
  }

  String getTitle() {
    return title;
  }

  String getDescription() {
    return description;
  }

  String getContent() {
    return content;
  }
}
