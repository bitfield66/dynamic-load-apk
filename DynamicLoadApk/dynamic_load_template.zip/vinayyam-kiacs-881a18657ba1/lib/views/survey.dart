import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class SurveyPage extends StatefulWidget {
  String url = "";

  SurveyPage(String url) {
    this.url = url;
  }

  @override
  _SurveyPage createState() => new _SurveyPage(url);
}

class _SurveyPage extends State<SurveyPage> {
  String url = "";

  _SurveyPage(String url) {
    this.url = url;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Survey'),
      ),
      body: WebviewScaffold(
        url: 'https://www.kiacs.org/survey/',
        withZoom: true,
        withLocalStorage: true,
        hidden: true,
        initialChild: Container(
          color: Colors.grey,
          child: const Center(
            child: SizedBox(
              width: 40.0,
              height: 40.0,
              child: CircularProgressIndicator(),
            ),
          ),
        ),
      ),
    );
  }
}
