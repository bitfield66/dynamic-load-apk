class DashboardDO {
  String title;
  String image;

  DashboardDO setTitle(String title) {
    this.title = title;
    return this;
  }

  DashboardDO setImage(String image) {
    this.image = image;
    return this;
  }

  String getImage() {
    return image;
  }

  String getTitle() {
    return title;
  }
}
