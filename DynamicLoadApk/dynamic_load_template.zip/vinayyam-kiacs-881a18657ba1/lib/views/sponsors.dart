import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:kiacs/utils/colors.dart';

class SponsorsPage extends StatefulWidget {
  @override
  _SponsorsPage createState() => new _SponsorsPage();
}

Size size;

class _SponsorsPage extends State<SponsorsPage> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
            automaticallyImplyLeading: true,
            //`true` if you want Flutter to automatically add Back Button when needed,
            //or `false` if you want to force your own back button every where
            title: Text('Sponsors'),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            )),
        body: Stack(children: <Widget>[
          new Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                    image: new AssetImage("assets/images/background.png"),
                    fit: BoxFit.fill)),
          ),
          SingleChildScrollView(
            child: Container(
                child: Padding(
                    padding: EdgeInsets.all(20.0),
                    child: Center(
                      child: Column(
                        children: <Widget>[
                          addSponsorTitle('Platinum Sponsor'),
                          Divider(
                            color: Colors.grey,
                            endIndent: size.width / 5,
                            indent: size.width / 5,
                          ),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS1.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 30, 0, 10),
                          ),
                          addSponsorTitle('Silver Sponsors'),
                          getDriver(),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS2.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS3-1.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 30, 0, 10),
                          ),
                          addSponsorTitle('Bronze Sponsors'),
                          getDriver(),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS4.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS5-1.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS6.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                          addSponsorImage(
                              'https://www.kiacs.org/wp-content/uploads/2019/09/SPONSORS7.jpg'),
                          Padding(
                            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          ),
                        ],
                      ),
                    ))),
          )
        ]));
  }

  Divider getDriver() {
    return Divider(
      color: Colors.grey,
      endIndent: size.width / 5,
      indent: size.width / 5,
    );
  }

  Text addSponsorTitle(String sponsor) {
    return Text(
      sponsor,
      style: TextStyle(
          color: primaryColor, fontSize: 14.0, fontWeight: FontWeight.bold),
    );
  }

  Container addSponsorImage(String image) {
    return Container(
        width: size.width / 2,
        height: size.height / 6,
        child: Center(
          child: CachedNetworkImage(
            imageUrl: image,
            placeholder: (context, url) => Center(
              child: SizedBox(
                width: 40.0,
                height: 40.0,
                child: new CircularProgressIndicator(),
              ),
            ),
            errorWidget: (context, url, error) =>
                Image.asset("assets/images/placeholder.png"),
            fit: BoxFit.scaleDown,
          ),
        ));
  }
}
