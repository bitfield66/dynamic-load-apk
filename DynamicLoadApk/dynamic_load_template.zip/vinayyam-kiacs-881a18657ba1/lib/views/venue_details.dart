import 'package:flutter/material.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'maps_launcher.dart';

class VenueDetailsPage extends StatefulWidget {
  @override
  _VenueDetailsPage createState() => new _VenueDetailsPage();
}

Size size;

class _VenueDetailsPage extends State<VenueDetailsPage> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
            automaticallyImplyLeading: true,
            //`true` if you want Flutter to automatically add Back Button when needed,
            //or `false` if you want to force your own back button every where
            title: Text('Venue'),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            )),
        body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
            image: AssetImage("assets/images/background.png"),
            fit: BoxFit.cover,
          )),
          child: Stack(
            children: <Widget>[
              CachedNetworkImage(
                imageUrl:
                    'https://www.kiacs.org/wp-content/uploads/2019/09/The-Regency-Hotel-Kuwait.jpg',
                placeholder: (context, url) => Padding(
                  padding: EdgeInsets.fromLTRB(
                      size.width / 2, size.height / 10, 0, size.height / 10),
                  child: SizedBox(
                    width: 40.0,
                    height: 40.0,
                    child: new CircularProgressIndicator(),
                  ),
                ),
                errorWidget: (context, url, error) =>
                    Image.asset("assets/images/placeholder.png"),
                fit: BoxFit.cover,
                width: size.width,
                height: size.height / 3,
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(40, size.height / 3.5, 40, 0),
                child: Card(
                  child: Container(
                      width: size.width,
                      height: size.height / 2,
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.fromLTRB(20, 20, 0, 20),
                            child: Row(
                              children: <Widget>[
                                Text(
                                  "Venue",
                                  style: TextStyle(
                                      color: primaryColor,
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.bold),
                                ),
                                Spacer(),
                                Padding(
                                  padding: EdgeInsets.fromLTRB(0, 0, 20, 0),
                                  child:MaterialButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius: new BorderRadius.circular(0.0),
                                        side: BorderSide(color: primaryColor)
                                    ),
                                    onPressed: () => _launchMap(),
                                    child: Text('Directions'),
                                  )
                                )
                              ],
                            ),
                          ),
                          Padding(
                              padding: EdgeInsets.fromLTRB(40, 25, 40, 0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  getRow('assets/images/ic_map.png',
                                      'The Regency Hotel, Al Bida’a - Kuwait'),
                                  getSpacer(),
                                  getRow('assets/images/ic_calendar.png',
                                      '1st - 2nd December 2019'),
                                  getSpacer(),
                                  getRow('assets/images/ic_time.png',
                                      '8:00 AM - 3:00 PM'),
                                  getSpacer()
                                ],
                              ))
                        ],
                      )),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  elevation: 5,
                ),
              )
            ],
          ),
        ));
  }

  Row getRow(String path, String name) {
    return Row(
      children: [
        Padding(
          padding: EdgeInsets.only(left: 0, top: 10, bottom: 0, right: 0),
          child: Image.asset(
            path,
            width: 30,
            height: 30,
            color: primaryColor,
          ),
        ),
        Expanded(
            child: Padding(
          padding: EdgeInsets.only(left: 20, top: 0, bottom: 0, right: 0),
          child: Text(
            name,
            style: TextStyle(
                color: Colors.black,
                fontSize: 12.0,
                fontWeight: FontWeight.bold),
          ),
        )),
      ],
    );
  }

  _launchMap() async {
    MapsLauncher.launchQuery(
        'The Regency Kuwait, Al Bidea, 25 Al Ta\'awen Street, Salmiya, Kuwait، 220122576 6666');
  }

  Container getSpacer() {
    return Container(
      child: Column(
        children: <Widget>[
          SizedBox(height: 10),
          Divider(
            color: Colors.black,
            indent: size.width / 9,
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
