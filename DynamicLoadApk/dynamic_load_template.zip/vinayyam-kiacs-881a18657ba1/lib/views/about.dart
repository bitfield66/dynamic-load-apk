import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:kiacs/utils/colors.dart';

class AboutPage extends StatefulWidget {
  @override
  _AboutPage createState() => new _AboutPage();
}

Size size;

class _AboutPage extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
            automaticallyImplyLeading: true,
            //`true` if you want Flutter to automatically add Back Button when needed,
            //or `false` if you want to force your own back button every where
            title: Text('ABOUT KIACS'),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            )),
        body: Stack(children: <Widget>[
          Container(
              decoration: new BoxDecoration(
            image: new DecorationImage(
              fit: BoxFit.cover,
              image: AssetImage("assets/images/background.png"),
            ),
          )),
          SingleChildScrollView(
            child: Stack(
              children: <Widget>[
                CachedNetworkImage(
                  imageUrl:
                      'https://www.kiacs.org/wp-content/uploads/2019/10/about-kiacs-1.jpg',
                  placeholder: (context, url) => Center(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                          0, size.height / 10, 0, size.height / 10),
                      child: SizedBox(
                        width: 40.0,
                        height: 40.0,
                        child: new CircularProgressIndicator(),
                      ),
                    ),
                  ),
                  errorWidget: (context, url, error) =>
                      Image.asset("assets/images/placeholder.png"),
                  fit: BoxFit.cover,
                  width: size.width,
                  height: size.height / 3,
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(40, size.height / 3.6, 40, 0),
                  child: Card(
                    child: Container(
                        width: size.width,
                        child: Column(
                          children: <Widget>[
                            Center(
                                child: Padding(
                                    padding: EdgeInsets.fromLTRB(0, 20, 0, 20),
                                    child: Text(
                                      'KIACS 2019',
                                      style: TextStyle(
                                          color: primaryColor,
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.bold),
                                    ))),
                            Padding(
                                padding: EdgeInsets.fromLTRB(20, 0, 20, 20),
                                child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      "Kuwait Petroleum corporation and subsidiaries (KPC) & EQUATE petrochemical Company are jointly hosting the 4th edition of Industrial Control Systems (ICS) Cyber Security Conference – KIACS 2019 (Kuwait Industrial Automation and Control System). The conference aims to bring together the experts from Oil & Gas, Technology & numerous other industries to address critical concerns and trends with regard to the development of Cyber Security threats and cyber crisis in Industrial Control Systems.\n\n"
                                      "The event is hosted Under the Patronage of H.E. Dr. Khaled Ali Al-Fadhel, Minister of Oil and Minister of Electricity & Water for the State of Kuwait, and is scheduled on 1st - 2nd December 2019 at The Regency Hotel, Al Bida’a - Kuwait",
                                      textAlign: TextAlign.justify,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12.0,
                                          fontWeight: FontWeight.normal),
                                    )))
                          ],
                        )),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    elevation: 5,
                  ),
                )
              ],
            ),
          )
        ]));
  }
}
