import 'package:flutter/material.dart';
import 'package:kiacs/controller/agenda_controller.dart';
import 'package:kiacs/models/agenda_do.dart';
import 'package:timeline_list/timeline.dart';
import 'package:timeline_list/timeline_model.dart';

class AgendaPage extends StatefulWidget {
  @override
  _AgendaPage createState() => new _AgendaPage();
}

List<AgendaDO> listModel;
List<AgendaDO> listModelTwo;
Size size;

class _AgendaPage extends State<AgendaPage> {
  final PageController pageController =
      PageController(initialPage: 1, keepPage: true, viewportFraction: 0.8);
  int pageIx = 1;

  @override
  Widget build(BuildContext context) {
    AgendaController _agendaController = AgendaController();
    listModel = _agendaController.getListModelOne();
    listModelTwo = _agendaController.getListModelTwo();
    size = MediaQuery.of(context).size;
    List<Widget> pages = [
      Container(
          child: Padding(
              padding: EdgeInsets.fromLTRB(30, 30, 0, 5),
              child: timelineModel(TimelinePosition.Left))),
      timelineModelTwo(TimelinePosition.Left)
    ];
    return Scaffold(
        body: DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: Scaffold(
        appBar: AppBar(
            bottom: TabBar(
              tabs: [
                Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Text(
                      'Day 1 Program – 1 Dec 19',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                    )),
                Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Text(
                      'Day 2 Program – 2 Dec 19',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                    )),
              ],
            ),
            title: Text('Agenda'),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context, false),
            )),
        body: Stack(children: <Widget>[
          new Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                    image: new AssetImage("assets/images/background.png"),
                    fit: BoxFit.fill)),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(20.0, 0, 10, 0),
            child: TabBarView(
              children: [
                timelineModel(TimelinePosition.Left),
                timelineModelTwo(TimelinePosition.Left)
              ],
            ),
          )
        ]),
      ),
    ));
  }

  timelineModel(TimelinePosition position) => Timeline.builder(
      itemBuilder: centerTimelineBuilder,
      itemCount: listModel.length,
      physics: position == TimelinePosition.Left
          ? ClampingScrollPhysics()
          : BouncingScrollPhysics(),
      position: position);

  TimelineModel centerTimelineBuilder(BuildContext context, int i) {
    final agendaDO = listModel[i];
    return TimelineModel(
        Container(
          width: size.width,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: size.width / 5,
                child: Text(
                  agendaDO.from + "-" + agendaDO.to,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 13.0,
                      fontWeight: FontWeight.normal),
                ),
              ),
              Flexible(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
                    child: Text(
                      agendaDO.name,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                      child: Text(
                        "Duration: " + agendaDO.duration,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14.0,
                            fontWeight: FontWeight.normal),
                      )),
                ],
              ))
            ],
          ),
        ),
        position: TimelineItemPosition.left,
        isFirst: i == 0,
        isLast: i == listModel.length,
        iconBackground: Colors.cyan,
        icon: Icon(Icons.star, color: Colors.white));
  }

  timelineModelTwo(TimelinePosition position) => Timeline.builder(
      itemBuilder: centerTimelineBuilderTwo,
      itemCount: listModelTwo.length,
      physics: position == TimelinePosition.Left
          ? ClampingScrollPhysics()
          : BouncingScrollPhysics(),
      position: position);

  TimelineModel centerTimelineBuilderTwo(BuildContext context, int i) {
    final agendaDO = listModelTwo[i];
    return TimelineModel(
        Container(
          width: size.width,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 90,
                child: Text(
                  agendaDO.from + "-" + agendaDO.to,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 13.0,
                      fontWeight: FontWeight.normal),
                ),
              ),
              Flexible(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
                    child: Text(
                      agendaDO.name,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 15),
                      child: Text(
                        "Duration: " + agendaDO.duration,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14.0,
                            fontWeight: FontWeight.normal),
                      )),
                ],
              ))
            ],
          ),
        ),
        position:
            i % 2 == 0 ? TimelineItemPosition.right : TimelineItemPosition.left,
        isFirst: i == 0,
        isLast: i == listModelTwo.length,
        iconBackground: Colors.cyan,
        icon: Icon(Icons.star, color: Colors.white));
  }
}
