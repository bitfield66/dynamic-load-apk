import 'package:flutter/material.dart';
import 'package:kiacs/_routing/routes.dart';
import 'package:kiacs/views/landing.dart';
import 'package:kiacs/views/dashboard.dart';
import 'package:kiacs/views/speakers.dart';
import 'package:kiacs/views/about.dart';
import 'package:kiacs/views/sponsors.dart';
import 'package:kiacs/views/agenda.dart';
import 'package:kiacs/views/venue_details.dart';
import 'package:kiacs/views/survey.dart';
import 'package:kiacs/views/gallery.dart';
import 'package:kiacs/views/youtube.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case landingViewRoute:
      return MaterialPageRoute(builder: (context) => LandingPage());
    case dashboardViewRoute:
      return MaterialPageRoute(builder: (context) => DashboardPage());
    case speakersViewRoute:
      return MaterialPageRoute(builder: (context) => SpeakersPage());
    case venueViewRoute:
      return MaterialPageRoute(builder: (context) => VenueDetailsPage());
    case sponsorsViewRoute:
      return MaterialPageRoute(builder: (context) => SponsorsPage());
    case agendaViewRoute:
      return MaterialPageRoute(builder: (context) => AgendaPage());
    case aboutViewRoute:
      return MaterialPageRoute(builder: (context) => AboutPage());
    case surveyViewRoute:
      return MaterialPageRoute(builder: (context) => SurveyPage("https://www.kiacs.org/survey/"));
    case galleryViewRoute:
      return MaterialPageRoute(builder: (context) => GalleryPage());
    case youtubeViewRoute:
      return MaterialPageRoute(builder: (context) => YoutubePage());
    default:
      return MaterialPageRoute(builder: (context) => LandingPage());
  }
}
