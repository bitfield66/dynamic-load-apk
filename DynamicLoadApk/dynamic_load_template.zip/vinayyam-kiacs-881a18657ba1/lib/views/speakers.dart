import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kiacs/models/speakers_do.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:kiacs/views/speakers_detail.dart';

class SpeakersPage extends StatefulWidget {
  @override
  _SpeakersPage createState() => new _SpeakersPage();
}

class _SpeakersPage extends State<SpeakersPage> {
  final databaseReference = Firestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: true,
          //`true` if you want Flutter to automatically add Back Button when needed,
          //or `false` if you want to force your own back button every where
          title: Text('Speakers'),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context, false),
          )),
      body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
            image: AssetImage("assets/images/background.png"),
            fit: BoxFit.cover,
          )),
          child: StreamBuilder(
              stream: databaseReference.collection("speakers").snapshots(),
              builder: (BuildContext context, AsyncSnapshot snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: CircularProgressIndicator());
                } else {
                  return Padding(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: GridView.count(
                          crossAxisCount: 3,
                          crossAxisSpacing: 5.0,
                          mainAxisSpacing: 5.0,
                          childAspectRatio: 6 / 9.0,
                          children: List.generate(
                              snapshot.data.documents.length, (i) {
                            return GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => SpeakersDetailPage(),
                                    ),
                                  );
                                },
                                child: Container(
                                  child: Padding(
                                    padding: EdgeInsets.all(6.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        AspectRatio(
                                          aspectRatio: 11.0 / 12.0,
                                          child: CachedNetworkImage(
                                            imageUrl: snapshot.data.documents[i]
                                                ['image'],
                                            placeholder: (context, url) =>
                                                Center(
                                              child: SizedBox(
                                                width: 40.0,
                                                height: 40.0,
                                                child:
                                                    new CircularProgressIndicator(),
                                              ),
                                            ),
                                            errorWidget: (context, url,
                                                    error) =>
                                                Image.asset(
                                                    "assets/images/placeholder.png"),
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                        Padding(
                                            padding:
                                                EdgeInsets.fromLTRB(0, 5, 0, 5),
                                            child: Center(
                                                child: Text(
                                              snapshot.data.documents[i]
                                                  ['title'],
                                              style: TextStyle(
                                                fontSize: 10.0,
                                                color: primaryColor,
                                                fontWeight: FontWeight.bold,
                                              ),
                                              textAlign: TextAlign.center,
                                            ))),
                                        Center(
                                            child: Text(
                                          snapshot.data.documents[i]
                                              ['description'],
                                          style: TextStyle(
                                            color: primaryColor,
                                            fontSize: 8.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          textAlign: TextAlign.center,
                                        )),
                                      ],
                                    ),
                                  ),
                                ));
                          })));
                }
              })),
    );
  }
}
