import 'package:kiacs/models/speakers_do.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SpeakersController {
  List<SpeakersDO> listModel;

  SpeakersController() {
    listModel = List<SpeakersDO>();
  }

  List<SpeakersDO> getListModel() {
    Map<String, String> eventsHashMap = new Map();
    if (listModel != null) {
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Ben-Miller.jpg')
          .setTitle('BENJAMIN MILLER ALAN')
          .setContent(
              'Ben Miller is Vice President of Professional Services and R&D at the industrial cyber security company Dragos, Inc. where he leads a team of analysts in performing active defense inside of ICS/SCADA networks. In this capacity he is responsible for a range of services including threat hunting, incident response, penetration testing and assessments for industrial community as well as advanced research and innovation within ICS security. '
              'Previous to his role at Dragos, Inc. Ben was the Associate Director, Electricity Information Sharing & Analysis Center (Electricity ISAC) and led cyber analysis for the sector. He and his team focused on leading edge cyber activities as they relate to the North American bulk electric system. Ben was recognized as instrumental in building new capabilities surrounding information sharing and analytics in his five years at the E-ISAC. Prior to joining the E-ISAC, Ben built and led a team of 9 focused on Network Security Monitoring, forensics, and incident response at a Fortune 150 energy firm. His team received numerous accolades from industry and law enforcement. During this time he also served in a CIP implementation project and various enterprise-wide mitigation programs. '
              'Ben has served in various roles including both planner and player roles in GridEx I, II, and III. He served as a facilitator of several NERC Task Forces including the Cyber Attack Task Force, and is an acknowledged contributor to NIST SP 800-150. Ben is an accomplished speaker in various venues including Black Hat, SANS, ICSJWG, ShmooCon and others. He was recognized by SANS as a 2017 Difference Maker Award Winner for his contributions to the electricity sector.')
          .setDescription('Dragos'));
      listModel.add(SpeakersDO()
          .setImage('assets/images/placeholder.png')
          .setTitle('LAYALI AL-MANSOURI')
          .setContent(
              '                                                                                                                                                    ')
          .setDescription('CITRA'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Joel-Langill.jpg')
          .setTitle('JOEL LANGILL')
          .setContent(
              'Joel Langill is a part of the Critical Infrastructure Protection team at AECOM where he serves as the Director of Industrial CyberSecurity Services. In his role, he leads and develops teams within AECOM’s global organization focusing on the identification of cyber-physical threats, how they could potentially exploit system and operational weaknesses across cyber, physical and electromagnetic spectrum domains, and how this could impact essential business, manufacturing and mission operations. Cyber security services span multiple sectors including defense, transportation, energy, sporting and entertainment venues, facility management, smart cities, to name a few. Prior to joining AECOM, Joel founded SCADAhacker.com – a site devoted to industrial cyber security. He has worked for over 30 years exclusively in the industrial automation and control industry where he was involved in designing, implementing and supporting automation solutions for global infrastructure projects spanning the globe. '
              'His experience includes integrated control system architectural design, product development, project implementation, and system migration in a variety of roles having exposure to most industry sectors. Having worked on both greenfield and brownfield projects around the world, Joel has rare and insightful insight into the risks and mitigation of cyber threats in operational systems as they have been designed, deployed, and maintained. Joel offers one of the leading training courses on ICS cyber security, and was the co-author of the popular book on the subject “Industrial Network Security”. Joel is a member of the ISA 84 and ISA99 committees on functional safety and industrial security for control systems.')
          .setDescription('ENGlobal Automation'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Omar-Sherin.jpg')
          .setContent(
              'Omar holds a Bachelor of Science degree in computer engineering with more than 16 years of professional Information security,ICS security experience and certified as GICSP, CBCP, CRISC, CERT CIH and ISO27001LA. He is a voting member in the ISA99 now IEC/ISA-62443 standard for SCADA Security and an international partner in the Industrial Control Systems Joint Working Group (ICSJWC) created by the DHS. He was also a member of the OWASP foundation leader’s board. He led the development of the first National Standard for Industrial Control Systems (ICS) security and contributed to drafting the first Critical Infrastructure Information Protection (CIIP) law in the MENA region, He is also proud to lead the team that organized and implemented the 1st National Cyber Security Drills in the Middle East [STAR-X], and he holds a diploma from Carnegie Mellon’s Tepper School of Business in entrepreneurship and corporate innovation.'
              'He has worked for several multinational firms in the oil and gas sector as a security engineer and officer, and on his spare time blogging in (ciip.wordpress.com) and a regular speaker, columnist on information security and Critical Infrastructure Information Protection (CIIP) issues. Currently he is a Cyber Security Director in Ernest and Young (MENA Region) focusing on protecting Critical Infrastructures and securing Operation Technologies (OT).')
          .setTitle('OMAR SHERIN')
          .setDescription('Cyber Security Director at EY'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Ira-Winkler.jpg')
          .setTitle('IRA WINKLER')
          .setContent(
              'Ira Winkler, CISSP is President of Secure Mentem and author of Advanced Persistent Security. He is considered one of the world’s most influential security professionals, and has been named a “Modern Day James Bond” by the media. He did this by performing espionage simulations, where he physically and technically “broke into” some of the largest companies in the World and investigating crimes against them, and telling them how to cost effectively protect their information and computer infrastructure. He continues to perform these espionage simulations, as well as assisting organizations in developing cost effective security programs. Ira also won the Hall of Fame award from the Information Systems Security Association, as well as several other prestigious industry awards. Most recently, CSO Magazine named Ira a CSO Compass Award winner as The Awareness Crusader. '
              'Ira is also author of the riveting, entertaining, and educational books, Advanced Persistent Security, Spies Among Us and Zen and the Art of Information Security. He is also a columnist for DarkReading and ComputerWorld, and writes for several other industry publications. Mr. Winkler has been a keynote speaker at almost every major information security related event, on 6 continents, and has keynoted events in many diverse industries. He is frequently ranked among, if not the, top speakers at the events. '
              'Mr. Winkler began his career at the National Security Agency, where he served as an Intelligence and Computer Systems Analyst. He moved onto support other US and overseas government military and intelligence')
          .setDescription('Secure Mentem'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Eric-Byres-.jpg')
          .setTitle('ERIC BYRES')
          .setContent(
              'Eric Byres is widely recognized as one of the world’s leading experts in the field of industrial control system (ICS) and Industrial Internet of Things (IIoT) cybersecurity. He is the inventor of the Tofino Security technology – the most widely deployed ICS-specific firewall in the world – licensed by industry giants Honeywell, Schneider Electric, and Caterpillar. Eric is also known for his leadership in international standards and research for industrial communications. '
              'Eric holds an extensive list of accomplishments, which includes founding the BCIT Critical Infrastructure Security Centre, providing guidance to government security agencies and major energy companies on protection for critical infrastructures, sitting as the chair of the ISA SP-99 Security Technologies Working Group, representing Canada for the IEC TC65/WG10 standards effort, and testifying to the US Congress on the Security of Industrial Control Systems in National Critical Infrastructures. He has received numerous awards from international organizations and was made an ISA Fellow in 2009. In 2013 he received ISA’s highest honor.')
          .setDescription('ADOLUS'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Sam-Wilson.jpg')
          .setTitle('SAM WILSON')
          .setContent(
              'Sam Wilson is the global product marketing manager responsible for multiple operational technology (OT) cybersecurity products, including the Honeywell Forge Cybersecurity Platform. Throughout his career at Honeywell, he has led initiatives across corporate security and IT operations, including four years in Honeywell’s Global Security Risk Assessment team. Based in Canada, Sam is a graduate of Western University in London, Ontario and holds CISSP, GICSP and Six Sigma Black Belt certifications. '
              'He is an active member of the SANS ICS community and is passionate about improving the effectiveness of cybersecurity products. His personal interests include wilderness hiking and international travel.')
          .setDescription('Honeywell'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Peter-Reynolds.jpg')
          .setContent(
              'Peter is an Analyst and Consultant with ARC Advisory Group global research and advisory firm headquartered in Boston, USA. Peter performs research into and consults with clients on industry best practices, process and asset optimization, and cybersecurity. He brings more than 27 years of professional experience in the energy and chemicals industry and has also published several papers related to digitalization. Peter frequently speaks at conferences throughout North America, Europe, and the Middle East')
          .setTitle('PETER REYNOLDS')
          .setDescription('ARC'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Jay-Abdallah.jpg')
          .setTitle('JAY ABDALLAH')
          .setContent(
              'Jay is responsible for developing the growth strategy for Schneider Electric’s cybersecurity business, including solution design, and sales support and training. He has more than 18 years’ enterprise-class experience designing and implementing sophisticated endpoint security systems. He is active in several security organizations and holds a multitude of industry certifications including CISSP, CISM, CISA, ISO 27001 Lead Auditor, and ISA99 Cybersecurity Specialist.')
          .setDescription('Schnieder'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Tassos-Dimitriou.jpeg')
          .setTitle('DR. TASSOS DIMITRIOU')
          .setContent(
              'Dr. Tassos Dimitriou is a professor at the Department of Computer Engineering at Kuwait University. Prior to that he was an Associate Professor at Athens Information Technology, Greece, where he was leading the Algorithms and Security group, and adjunct Professor in Carnegie Mellon University, USA, and Aalborg University, Denmark. Dr. Dimitriou conducts research in areas spanning from the theoretical foundations of cryptography to the design and implementation of leading edge efficient and secure communication protocols. Emphasis is given in authentication and privacy issues for various types of networks (adhoc, sensor nets, RFID, smart grid, etc.), security architectures for wireless and telecommunication networks and the development of secure applications for networking and electronic commerce. His research in the above fields has resulted in numerous publications, some of which received distinction, and numerous invitations for talks in prestigious conferences. '
              'Dr. Dimitriou is a senior member of IEEE, ACM, a Fulbright fellow and Distinguished Lecturer of ACM. More information about him can be found in the web page http://tassosdimitriou.com/')
          .setDescription('Kuwait University'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/John-Matherly.jpg')
          .setContent(
              'Shodan is a search engine for Internet-connected devices. Web search engines, such as Google and Bing, are great for finding websites. But what if you\'re '
              'interested in measuring which countries are becoming more connected? Or if you want to know which version of Microsoft IIS is the most popular? Or you want to find the control servers for malware? Shodan gathers information about all devices directly connected to the Internet. If a device is directly hooked up to the Internet then Shodan queries it for various publicly-available information. The types of devices that are indexed can vary tremendously: ranging from small desktops up to nuclear power plants and everything in between. So what does Shodan index then? The bulk of the data is taken from banners, which are metadata about a software that\'s running on a device. This can be information about the server software, what options the service supports, a welcome message or anything else that the client would like to know before interacting with the server.')
          .setTitle('JOHN MATHERLY')
          .setDescription('Shodan'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Luca-Martelli.jpg')
          .setContent(
              'Currently responsible for Oracle\'s Security & Systems Management portfolio in Europe Middle East and Africa with leadership of Business Development activities and Product Strategy. Luca is continuously supporting Organizations that are embracing their journey to the cloud, making sure security by design and security by default are the key cornerstones to improve their digital security posture, in this continuously evolving hybrid IT scenario. Discussing Security, Cloud Security, the Cloud Shared Responsibility Model, Systems Management with C-Level across top customers in EMEA in order to ensure a proper balance between the speed of innovation and the need to ensure data protection (i.e. GPDR) and proper security and risk management plans are in place. Luca has spent the majority of his time in security. He started his duties at Oracle in 2011, he has been Identity & Security Lead for the Italy&Greece cluster at Novell and before as project lead for Cambridge Technology Partner managing and delivering the very first projects in the Identity Management space in Europe. Luca is a frequent speaker on technology and security at industry events. Luca has an Executive MBA from Bologna Business School.')
          .setTitle('LUCA MARTELLI')
          .setDescription('ORACLE'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Dana-Spataru.jpg')
          .setTitle('DANA SPATARU')
          .setContent(
              'Currently busy with building the IOT security practice in EMEA, including Industrial Control Systems and Cloud security. I am working on large cyber security transformations in both IT and OT environments, helping organizations manage their cyber risk holistically. Areas of focus: - M&A security - managing cyber risk during digital transformations - security as enabler for efficiency gaining and cost reduction.”')
          .setDescription('Deloitte'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Gilles-Loridon.jpg')
          .setTitle('GILLES LORIDON')
          .setContent(
              'Gilles LORIDON has worked as an IT/OT Consultant for twenty-five years and as Cyber Security Consultant for more than twenty years. Gilles joined the ISA chapters in UAE and in other GCC countries, focusing on the IT/OT Cyber Committees and raising awareness in the GCC about ISA/IEC 62443 in general and implementation lessons learned. Gilles being the Principal Advisor for the Nuclear Regulatory body in UAE, FANR, has also first-hand experience of Cyber Security regulatory challenges as well as technical inspections support. Having ISA/IEC 62443 Cyber Security Management System development and implementation experience as well as insight into Regulatory and Standard efforts, Gilles has an unique perspective on the IT/OT Cyber Security. Gilles is certified ISA/IEC 62443 Cyber Security Fundamentals Specialist.')
          .setDescription('Global Security'));
      listModel.add(SpeakersDO()
          .setImage(
              'https://www.kiacs.org/wp-content/uploads/2019/10/Gilles-Loridon.jpg')
          .setTitle('AASEF IQBAL')
          .setContent(
              'Aasef, is an Operational Technology (OT) Cybersecurity Professional15+ years of experience in OT, presently working with Fortinet as Sr. Specialist – OT Cybersecurity and responsible for OT cybersecurity in EMEA region. He has worked with manufacturing, telecom and power utility sector in operational and management roles to improve cybersecurity posture of OT environments. He is specialized in designing and implementing cybersecurity architectures and solutions, cyber security assurance testing, risk assessment, penetration testing and in developing cybersecurity policies and compliance programs for OT systems. He has participated and delivered various OT infrastructure and cybersecurity projects such as Power Transmission Substations, Power Transmission and Distribution Control Centres, Cybersecurity Management System, Crisis Management Command Centre, Cybersecurity Operations Centre and Smart Grid Cybersecurity. Aasef, holds many technology certifications including, well-known information security management certifications, CISSP and CISM. He is also an ISA/IEC 62443 Cybersecurity Expert, an OT cybersecurity credential awarded by the globally recognized authority in industrial automation and control systems, the International Society of Automation (ISA). Furthermore, he is also certified in GICSP and GRID, the OT specific cybersecurity certification programs from the SANS Institute.')
          .setDescription('Fortinet, UAE'));
    }
//    for (int i = 0; i < listModel.length; i++) {
//      Map<String, String> values = new Map();
//      values.putIfAbsent("title", () => listModel[i].getTitle());
//      values.putIfAbsent("image", () => listModel[i].getImage());
//      values.putIfAbsent("content", () => listModel[i].getContent());
//      values.putIfAbsent("description", () => listModel[i].getDescription());
//      Firestore.instance
//          .collection("speakers")
//          .document(listModel[i].getTitle())
//          .setData(values);
//    }
    return listModel;
  }
}
