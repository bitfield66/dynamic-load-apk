import 'package:flutter/material.dart';
import 'dart:async';
import 'package:kiacs/_routing/routes.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:device_info/device_info.dart';
import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => new _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  @override
  void initState() {
    super.initState();
    setupRemoteConfig();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Center(
            child: new Image.asset(
              'assets/images/bg_splash.png',
              width: size.width,
              height: size.height,
              fit: BoxFit.fill,
            ),
          )
        ],
      ),
    );
  }

  void setupRemoteConfig() async {
    final RemoteConfig remoteConfig = await RemoteConfig.instance;

    remoteConfig.setConfigSettings(RemoteConfigSettings(debugMode: false));
    remoteConfig.setDefaults(<String, dynamic>{
      'applicationId': 'demo',
    });
    await remoteConfig.notifyListeners();
    try {
      await remoteConfig.fetch(expiration: const Duration(seconds: 0));
      await remoteConfig.activateFetched();

      FirebaseMessaging firebaseMessaging = new FirebaseMessaging();
      String deviceName;
      String deviceVersion;
      String identifier;
      final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();
      try {
        if (Platform.isAndroid) {
          var build = await deviceInfoPlugin.androidInfo;
          deviceName = build.model;
          deviceVersion = build.version.toString();
          identifier = build.androidId; //UUID for Android
        } else if (Platform.isIOS) {
          var data = await deviceInfoPlugin.iosInfo;
          deviceName = data.name;
          deviceVersion = data.systemVersion;
          identifier = data.identifierForVendor; //UUID for iOS
        }

        firebaseMessaging.getToken().then((token) {
          Map<String, String> values = new Map();
          values.putIfAbsent("deviceName", () => deviceName);
          values.putIfAbsent("deviceVersion", () => deviceVersion);
          values.putIfAbsent("identifier", () => identifier);
          values.putIfAbsent(
              "firebase_token", () => token);
          Firestore.instance
              .collection("users")
              .document(identifier)
              .setData(values);
        });
      } on Exception {
        print('Failed to get platform version');
      }

      if (remoteConfig.getString("applicationId") == "demo") {
        Timer(Duration(seconds: 4),
            () => Navigator.pushReplacementNamed(context, dashboardViewRoute));
      } else {
        showDialog(
            context: context,
            builder: (_) => new AlertDialog(
                  title: new Text("Alert!!"),
                  content: new Text("You have reached limit for using app!!!"),
                  actions: <Widget>[
                    GestureDetector(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(0, 0, 20, 20),
                        child: Text(
                          "OK",
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 15.0,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      onTap: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ));
      }
    } on FetchThrottledException catch (exception) {
      // Fetch throttled.
      print(exception);
    } catch (exception) {
      print('Unable to fetch remote config. Cached or default values will be '
          'used');
    }
  }
}
