import 'package:flutter/material.dart';
import 'dart:ui';

const primaryColor = const Color(0xFF002e5c);
const primaryLight = const Color(0xFF002e5c);
const primaryDark = const Color(0xFF002e5c);

const secondaryColor = const Color(0xFF002e5c);
const secondaryLight = const Color(0xFF002e5c);
const secondaryDark = const Color(0xFF002e5c);
const aboutColor = const Color(0xFF98A3AF);

const Color gradientStart= const Color(0xFF472710);
const Color gradientEnd  = const Color(0xFFffffff);
const Color dashboardIcon = const Color(0XFF214F93);
const Color dashboardText = const Color(0XFFF2F2F2);

const primaryGradient = const LinearGradient(
  colors: const [gradientStart, gradientEnd],
  stops: const [0.0, 1.0],
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
);