import 'package:flutter/material.dart';

class AgendaDO {
  String name;
  String duration;
  String from;
  String to;
  String session;

  AgendaDO(this.name, this.duration, this.from, this.to, this.session);

  AgendaDO setName(String name) {
    this.name = name;
    return this;
  }

  AgendaDO setDuration(String duration) {
    this.duration = duration;
    return this;
  }

  AgendaDO setFrom(String from) {
    this.from = from;
    return this;
  }

  AgendaDO setTo(String to) {
    this.to = to;
    return this;
  }

  AgendaDO setSession(String session) {
    this.session = session;
    return this;
  }

  String getName() {
    return name;
  }

  String getDuration() {
    return duration;
  }

  String getFrom() {
    return from;
  }

  String getTo() {
    return to;
  }

  String getSession() {
    return session;
  }
}
