import 'package:flutter/material.dart';

class AppConfig {
  static const appName = "KIACS";
  static const appTagline = "INNOVATE-AUTOMATE-SECURE";
}

class AvailableFonts {
  static const primaryFont = "Quicksand";
}

class AvailableImages {
  static const homePage = const AssetImage('assets/images/home_page.png');
  static const appLogo = const AssetImage('assets/images/logo.png');
}
