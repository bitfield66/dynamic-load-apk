import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:kiacs/app.dart';

void main(){

  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: primaryDark
  ));
  runApp(MyApp());
}
