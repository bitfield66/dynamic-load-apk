import 'package:kiacs/models/dashboard_do.dart';

class DashboardController {
  List<DashboardDO> listModel;

  DashboardController() {
    listModel = List<DashboardDO>();
  }

  List<DashboardDO> getListModel() {
    if (listModel != null) {
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_about.png')
          .setTitle('ABOUT KIACS'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_venue.png')
          .setTitle('VENUE'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_speakers.png')
          .setTitle('SPEAKERS'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_agenda.png')
          .setTitle('AGENDA'));
      listModel.add(DashboardDO()
          .setImage('assets/images/channel.png')
          .setTitle('LIVESTREAM'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_sponsors.png')
          .setTitle('SPONSORS'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_survey.png')
          .setTitle('SURVEY'));
      listModel.add(DashboardDO()
          .setImage('assets/images/ic_notifications.png')
          .setTitle('NOTIFICATIONS'));
    }
    return listModel;
  }
}
