import 'package:flutter/material.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:kiacs/_routing/routes.dart';
import 'package:kiacs/controller/dashboard_controller.dart';
import 'package:kiacs/models/dashboard_do.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPage createState() => new _DashboardPage();
}

Size size;
bool arrowVisibility = true;

class _DashboardPage extends State<DashboardPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    DashboardController _dashboardController = DashboardController();
    List<DashboardDO> listModel = _dashboardController.getListModel();
    return Scaffold(
      body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
            image: AssetImage("assets/images/background.png"),
            fit: BoxFit.cover,
          )),
          child: Padding(
              padding: EdgeInsets.fromLTRB(30, 50, 30, 0),
              child: GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 20,
                crossAxisSpacing: 20,
                children: List<Widget>.generate(8, (index) {
                  return GestureDetector(
                      child: GridTile(
                        child: Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage("assets/images/bg_icon.png"),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: Stack(
                              children: <Widget>[
                                Positioned(
                                  child: new Align(
                                      alignment: FractionalOffset.center,
                                      child: Image(
                                        width: 60,
                                        height: 60,
                                        fit: BoxFit.scaleDown,
                                        image: AssetImage(
                                            listModel[index].getImage()),
                                      )),
                                ),
                                Positioned(
                                  child: new Align(
                                    alignment: FractionalOffset.bottomCenter,
                                    child: Padding(
                                        padding: EdgeInsets.only(bottom: 30.0),
                                        child: Text(listModel[index].getTitle(),
                                            style: TextStyle(
                                                color: dashboardText,
                                                fontSize: 9.0))),
                                  ),
                                )
                              ],
                            )),
                      ),
                      onTap: () {
                        _onTileClicked(index);
                      });
                }),
              ))),
    );
  }

  _onTileClicked(int index) {
    if (index == 0)
      Navigator.pushNamed(context, aboutViewRoute);
    else if (index == 1)
      Navigator.pushNamed(context, venueViewRoute);
    else if (index == 2)
      Navigator.pushNamed(context, speakersViewRoute);
    else if (index == 3)
      Navigator.pushNamed(context, agendaViewRoute);
    else if (index == 4)
      Navigator.pushNamed(context, youtubeViewRoute);
    else if (index == 5)
      Navigator.pushNamed(context, sponsorsViewRoute);
    else if (index == 6)
      Navigator.pushNamed(context, surveyViewRoute);
  }
}
