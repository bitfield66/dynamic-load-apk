import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:kiacs/models/speakers_do.dart';
import 'package:kiacs/utils/colors.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SpeakersDetailPage extends StatefulWidget {
  @override
  _SpeakersDetailPage createState() => new _SpeakersDetailPage();
}

class _SpeakersDetailPage extends State<SpeakersDetailPage> {
  PageController _pageController;
  final databaseReference = Firestore.instance;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: true,
          //`true` if you want Flutter to automatically add Back Button when needed,
          //or `false` if you want to force your own back button every where
          title: Text("Speaker Details"),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context, false),
          )),
      body: Center(
          child: Container(
              width: size.width,
              decoration: BoxDecoration(
                  image: DecorationImage(
                image: AssetImage("assets/images/background.png"),
                fit: BoxFit.cover,
              )),
              child: StreamBuilder(
                  stream: databaseReference.collection("speakers").snapshots(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (!snapshot.hasData) {
                      return Center(child: CircularProgressIndicator());
                    } else {
                      return PageView(
                          physics: new NeverScrollableScrollPhysics(),
                          controller: _pageController,
                          children: List.generate(
                              snapshot.data.documents.length, (i) {
                            return getRow(
                                snapshot.data.documents.length,
                                i,
                                SpeakersDO()
                                    .setImage(
                                        snapshot.data.documents[i]['image'])
                                    .setTitle(
                                        snapshot.data.documents[i]['title'])
                                    .setContent(
                                        snapshot.data.documents[i]['content'])
                                    .setDescription(snapshot.data.documents[i]
                                        ['description']));
                          }));
                    }
                  }))),
    );
  }

  Padding getRow(int length, int index, SpeakersDO speakersDO) {
    return Padding(
        padding: EdgeInsets.all(5),
        child: Row(
          children: <Widget>[
            getNavigation(_pageController, index, length,
                "assets/images/ic_arrow_left.png", false),
            Flexible(
              flex: 1,
              child: Stack(children: <Widget>[
                // The containers in the background
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: MediaQuery.of(context).size.height * .20,
                    ),
                    Container(
                      height: MediaQuery.of(context).size.height * .60,
                      child: Card(
                        semanticContainer: true,
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: primaryColor,
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(
                                30, size.height * 0.10, 30, 5),
                            child: SingleChildScrollView(
                                child: Column(
                              children: <Widget>[
                                Text(
                                  speakersDO.getTitle(),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.normal),
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  speakersDO.getDescription(),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.normal),
                                  textAlign: TextAlign.center,
                                ),
                                Padding(
                                  padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                                ),
                                Text(
                                  speakersDO.getContent(),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.normal),
                                  textAlign: TextAlign.center,
                                )
                              ],
                            ))),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        elevation: 5,
                      ),
                    ),
                  ],
                ),
                // The card widget with top padding,
                // incase if you wanted bottom padding to work,
                // set the `alignment` of container to Alignment.bottomCenter
                addSponsorImage(speakersDO.getImage())
              ]),
            ),
            getNavigation(_pageController, index, length,
                "assets/images/ic_arrow_right.png", true),
          ],
        ));
  }
}

GestureDetector getNavigation(PageController _pageController, int position,
    int length, String path, bool isRight) {
  if (position == 0 && !isRight) {
    return GestureDetector(
      child: SizedBox(
        width: size.width * 0.10,
      ),
    );
  } else if (position == (length - 1) && isRight) {
    return GestureDetector(
      child: SizedBox(
        width: size.width * .10,
      ),
    );
  } else {
    return GestureDetector(
      onTap: () {
        if (_pageController.hasClients) {
          _pageController.animateToPage(
            isRight ? position + 1 : position - 1,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
          );
        }
      },
      child: Image(
        image: AssetImage(path),
        width: size.width * 0.10,
        height: size.width * 0.10,
        fit: BoxFit.scaleDown,
      ),
    );
  }
}

Size size;

Container addSponsorImage(String image) {
  return Container(
    alignment: Alignment.topCenter,
    padding: EdgeInsets.only(top: size.height * 0.10, right: 0, left: 0),
    child: Container(
      height: size.height * 0.18,
      width: size.width * 0.4,
      child: Card(
        semanticContainer: true,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: CachedNetworkImage(
          imageUrl: image,
          placeholder: (context, url) => Center(
            child: SizedBox(
              width: 40.0,
              height: 40.0,
              child: new CircularProgressIndicator(),
            ),
          ),
          errorWidget: (context, url, error) =>
              Image.asset("assets/images/placeholder.png"),
          fit: BoxFit.cover,
        ),
        elevation: 5,
      ),
    ),
  );
}
